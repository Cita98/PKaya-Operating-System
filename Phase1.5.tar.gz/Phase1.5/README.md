Laboratorio di Sistemi Operativi 

	PHASE 1.5

Kernel del sistema operativo: Livello 3

Setup 


- Installa uMPS (https://github.com/tjonjic/umps)

- Lancia il comando make -f Makefile_templ

- Lancia umps2 e setta il kernel.core

- Ricorda di togliere le spunte in basso per Breakpoints ed Exceptions

- Avvia la macchina
	- Seleziona scheda "machine"
	- Power on 

- Apri il terminale 
	- Seleziona scheda "windows"
	- Terminal 0


Componenti gruppo
- Accorsi Martina 
- Bretta Luca
- Vicenzi Andrea
- Diachuk Andrii
